(function () {
  var root = document.documentElement;

  // Theme toggle (remembered per browser)
  try { var saved = localStorage.getItem("theme"); if (saved) root.setAttribute("data-theme", saved); } catch (e) {}
  document.getElementById("theme").addEventListener("click", function () {
    var dark = root.getAttribute("data-theme") === "dark" ||
      (!root.getAttribute("data-theme") && matchMedia("(prefers-color-scheme: dark)").matches);
    var next = dark ? "light" : "dark";
    root.setAttribute("data-theme", next);
    try { localStorage.setItem("theme", next); } catch (e) {}
  });

  // Mobile menu
  var menu = document.getElementById("menu"), btn = document.getElementById("menuBtn");
  btn.addEventListener("click", function () {
    var open = menu.classList.toggle("open");
    btn.setAttribute("aria-expanded", open);
  });
  menu.addEventListener("click", function (e) {
    if (e.target.tagName === "A") { menu.classList.remove("open"); btn.setAttribute("aria-expanded", "false"); }
  });

  // Project filter
  var buttons = document.querySelectorAll(".filters button");
  var cards = document.querySelectorAll(".card");
  buttons.forEach(function (b) {
    b.addEventListener("click", function () {
      var f = b.dataset.filter;
      buttons.forEach(function (x) { x.setAttribute("aria-pressed", x === b); });
      cards.forEach(function (c) { c.hidden = !(f === "all" || c.dataset.cat === f); });
    });
  });

  // Highlight current section in nav
  var links = document.querySelectorAll("nav a[href^='#']");
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (en.isIntersecting) {
        links.forEach(function (a) { a.classList.toggle("active", a.getAttribute("href") === "#" + en.target.id); });
      }
    });
  }, { rootMargin: "-45% 0px -50% 0px" });
  document.querySelectorAll("main section[id]").forEach(function (s) { io.observe(s); });

  // Contact form: opens the visitor's email app with the message filled in
  var form = document.getElementById("form"), status = document.getElementById("status");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var d = new FormData(form);
    var name = (d.get("name") || "").trim(), email = (d.get("email") || "").trim(), msg = (d.get("message") || "").trim();
    if (!name || !/^\S+@\S+\.\S+$/.test(email) || !msg) {
      status.textContent = "Enter your name, a valid email, and a message.";
      return;
    }
    var body = msg + "\n\nFrom: " + name + " (" + email + ")";
    window.location.href = "mailto:hello@example.com?subject=" + encodeURIComponent("Portfolio message from " + name) +
      "&body=" + encodeURIComponent(body);
    status.textContent = "Opening your email app to send the message.";
  });

  document.getElementById("year").textContent = new Date().getFullYear();
})();
